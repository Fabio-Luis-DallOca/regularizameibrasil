# Regulariza MEI Brasil

Landing page oficial da **Regulariza MEI Brasil** — assessoria digital especializada em serviços para Microempreendedores Individuais (MEI).

## Tecnologias

- HTML5
- CSS3
- JavaScript (vanilla, embutido no index.html)

## Objetivo

Oferecer serviços de regularização e suporte para Microempreendedores Individuais (MEI), incluindo:

- Emissão de DAS (mensal e anual)
- Emissão de Notas Fiscais de Serviço
- Regularização de CNPJ
- Parcelamento de Débitos junto à Receita Federal

## Estrutura do projeto

```
regularizameibrasil/
├── index.html          # Página principal (HTML + CSS + JS embutidos)
├── privacidade.html    # Política de Privacidade
├── termos.html         # Termos de Uso
├── lgpd.html           # Adequação à LGPD
├── sitemap.xml         # Mapa do site para Google Search Console
├── robots.txt          # Instruções para robôs de busca
├── images/
│   ├── logo.png        # Logo horizontal (versão para fundo escuro)
│   ├── og-image.jpg    # Imagem para compartilhamento (Open Graph / WhatsApp)
│   ├── favicon.png     # Ícone da aba do navegador (símbolo M✓)
│   └── foto-perfil.png # Foto de perfil para Instagram / WhatsApp Business
└── README.md           # Este arquivo
```

## Funcionalidades

- Design responsivo (mobile first)
- SEO otimizado (meta tags, Open Graph, Schema.org JSON-LD)
- Acessibilidade (ARIA labels, prefers-reduced-motion)
- FAQ interativo com accordion
- Botão flutuante de WhatsApp
- Seção de planos com pagamento via Mercado Pago
- Política de Privacidade e Termos de Uso em conformidade com a LGPD
- Ano do copyright atualizado automaticamente via JavaScript

## Configurações pendentes (após publicar)

- [ ] Ativar Google Tag Manager: descomentar o bloco GTM no `<head>` e substituir `GTM-XXXXXXX` pelo ID real
- [ ] Ativar Meta Pixel: descomentar o bloco no `<head>` e substituir `XXXXXXXXXXXXXXX` pelo Pixel ID real
- [ ] Substituir depoimentos fictícios pelos reais quando disponíveis

## Contato

- Instagram: [@regularizameibrasil](https://instagram.com/regularizameibrasil)
- WhatsApp: [(11) 99556-8496](https://wa.me/5511995568496)
- Site: [https://www.regularizameibrasil.com.br](https://www.regularizameibrasil.com.br)

---

*© 2026 Regulariza MEI Brasil. Todos os direitos reservados.*
